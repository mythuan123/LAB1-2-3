<!DOCTYPE html>
<html>
<head>
    <title>Tính Diện Tích và Chu Vi</title>
</head>
<body>

<form method="get" action="#">
    <label for="chieudai">Chiều dài:</label>
    <input type="text" name="chieudai"><br><br>
    
    <label for="chieurong">Chiều rộng:</label>
    <input type="text" name="chieurong"><br><br>
    
    <input type="Submit" value="Tính" name="Submit">
</form>

<?php
if(isset($_GET['Submit']) && ($_GET['Submit'] == "Tính")) {
    $dai = isset($_GET['chieudai']) ? (float)$_GET['chieudai'] : 0;
    $rong = isset($_GET['chieurong']) ? (float)$_GET['chieurong'] : 0;

    $dientich = $dai * $rong;
    $chuvi = 2 * ($dai + $rong);

    echo "<br>Diện tích: " . $dientich . "<br>";
    echo "Chu vi: " . $chuvi;
}
?>

</body>
</html>
